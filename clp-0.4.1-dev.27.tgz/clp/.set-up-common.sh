#!/usr/bin/env bash

# Common utilities for Helm chart set-up scripts
# Source this file from set-up-*.sh scripts

set -o errexit
set -o nounset
set -o pipefail

# Creates required directories for CLP data
create_clp_directories() {
    echo "Creating CLP directories at ${CLP_HOME}..."
    mkdir -p "$CLP_HOME/samples"
}

# Downloads sample datasets in the background
# Sets SAMPLE_DOWNLOAD_PID global variable
download_samples() {
    echo "Downloading sample datasets..."
    wget -O - https://zenodo.org/records/10516402/files/postgresql.tar.gz?download=1 \
      | tar xz -C "$CLP_HOME/samples" &
    SAMPLE_DOWNLOAD_PID=$!

    # Generate sample log file for garbage collector testing
    cat <<EOF > "$CLP_HOME/samples/test-gc.jsonl"
{"timestamp": $(date +%s%3N), "level": "INFO", "message": "User login successful"}
{"timestamp": $(date +%s%3N), "level": "ERROR", "message": "Database connection failed"}
EOF
}

# Cleans up existing cluster and prepares environment
# @param {string} cluster_name Name of the kind cluster
prepare_environment() {
    local cluster_name=$1

    echo "Deleting existing cluster if present..."
    kind delete cluster --name "${cluster_name}" 2>/dev/null || true

    rm -rf "$CLP_HOME"
    create_clp_directories
    download_samples
}

# Loads a local Docker image into the kind cluster and returns the helm --set
# flags for using it. If image is not specified, returns empty string.
#
# @param {string} cluster_name Name of the kind cluster
# @param {string} component Flat image component name (e.g., "clpPackage", "mariadb", "resultsCache")
# @param {string} [image] Docker image (e.g., "clp-package:dev-junhao-a6bf")
# @return Prints helm --set flags to stdout
get_image_helm_args() {
    local cluster_name=$1
    local component=$2
    local image="${3:-}"

    if [[ -z "${image}" ]]; then
        return
    fi

    echo "Loading local image '${image}' into kind cluster..." >&2
    kind load docker-image "${image}" --name "${cluster_name}" >&2

    # Split "repo:tag" on the last colon whose right-hand side contains no '/'
    # (so registry ports like localhost:5000/repo are not mistaken for tags).
    if [[ "${image}" =~ ^(.+):([^:/]+)$ ]]; then
        local repo="${BASH_REMATCH[1]}"
        local tag="${BASH_REMATCH[2]}"
    else
        echo "Error: '${image}' is not a valid image reference (expected repo:tag)." >&2
        return 1
    fi
    echo "--set" "image.${component}.repository=${repo}" \
         "--set" "image.${component}.tag=${tag}" \
         "--set" "image.${component}.pullPolicy=Never"
}

# Parses common arguments shared across set-up scripts.
# Sets CLP_PACKAGE_IMAGE and ENABLE_PRESTO global variables.
#
# @param {string[]} args Script arguments
parse_common_args() {
    CLP_PACKAGE_IMAGE=""
    ENABLE_PRESTO="false"
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --clp-package-image)
                if [[ $# -lt 2 || "$2" == --* ]]; then
                    echo "Error: '--clp-package-image' requires a value." >&2
                    exit 1
                fi
                CLP_PACKAGE_IMAGE="$2"
                shift 2
                ;;
            --presto)
                ENABLE_PRESTO="true"
                shift
                ;;
            *)
                echo "Unknown argument: $1" >&2
                exit 1
                ;;
        esac
    done
}

# Returns helm --set flags to expose the Web UI and API server via NodePort, at the ports
# generate_kind_config maps to the host.
#
# @return Prints helm --set flags to stdout
get_service_exposure_helm_args() {
    echo "--set" "clpConfig.webui.serviceType=NodePort" \
         "--set" "clpConfig.api_server.serviceType=NodePort"
}

# Returns helm --set flags to enable Presto with a minimal config.
# Only prints flags when ENABLE_PRESTO is "true"; otherwise prints nothing.
#
# @return Prints helm --set flags to stdout
get_presto_helm_args() {
    if [[ "${ENABLE_PRESTO}" != "true" ]]; then
        return
    fi

    echo "--set" "clpConfig.webui.query_engine=presto" \
         "--set" "clpConfig.presto.serviceType=NodePort" \
         "--set" "clpConfig.presto.port=30889" \
         "--set" "clpConfig.presto.coordinator.logging_level=INFO" \
         "--set" "clpConfig.presto.coordinator.query_max_memory_gb=1" \
         "--set" "clpConfig.presto.coordinator.query_max_memory_per_node_gb=1" \
         "--set" "clpConfig.presto.worker.query_memory_gb=4" \
         "--set" "clpConfig.presto.worker.system_memory_gb=8" \
         "--set-json" "clpConfig.presto.split_filter=$(tr -d '[:space:]' <<'SPLIT_FILTER'
{
  "clp.default.default": [{
    "columnName": "timestamp",
    "customOptions": {
      "rangeMapping": {
        "lowerBound": "begin_timestamp",
        "upperBound": "end_timestamp"
      }
    },
    "required": false
  }]
}
SPLIT_FILTER
)" \
         "--set" "clpConfig.api_server=null" \
         "--set" "clpConfig.results_cache.retention_period=null"
}

# Generates worker pool values with general, compression, and query replica counts.
#
# @param {int} general_replicas Number of general workers
# @param {int} compression_replicas Number of compression workers
# @param {int} query_replicas Number of query workers
# @return Prints Helm values YAML to stdout
get_spider_worker_values() {
    local general_replicas=$1
    local compression_replicas=$2
    local query_replicas=$3

    cat <<EOF
spider:
  spiderConfig:
    worker:
      pools:
        - name: "general"
          replicas: ${general_replicas}
          resource_group: null
        - name: "compression"
          replicas: ${compression_replicas}
          resource_group:
            external_id: "compression"
            password:
              secretKeyRef:
                name: '{{ include "clp.fullname" . }}-spider-resource-groups'
                key: "compression"
        - name: "query"
          replicas: ${query_replicas}
          resource_group:
            external_id: "query"
            password:
              secretKeyRef:
                name: '{{ include "clp.fullname" . }}-spider-resource-groups'
                key: "query"
EOF
}

# Generates kind cluster configuration YAML
#
# @param {int} num_workers Number of worker nodes (0 for single-node cluster)
generate_kind_config() {
    local num_workers=${1:-0}

    cat <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraMounts:
  - hostPath: /home
    containerPath: /home
  - hostPath: $CLP_HOME
    containerPath: $CLP_HOME
  extraPortMappings:
  - containerPort: 30000
    hostPort: 30000
    protocol: TCP
  - containerPort: 30017
    hostPort: 30017
    protocol: TCP
  - containerPort: 30301
    hostPort: 30301
    protocol: TCP
  - containerPort: 30302
    hostPort: 30302
    protocol: TCP
  - containerPort: 30306
    hostPort: 30306
    protocol: TCP
  - containerPort: 30800
    hostPort: 30800
    protocol: TCP
  - containerPort: 30889
    hostPort: 30889
    protocol: TCP
EOF

    for ((i = 0; i < num_workers; i++)); do
        cat <<EOF
- role: worker
  extraMounts:
  - hostPath: /home
    containerPath: /home
  - hostPath: $CLP_HOME
    containerPath: $CLP_HOME
EOF
    done
}

# Waits for all jobs to complete and all non-job pods to be ready.
#
# @param {int} timeout_seconds Overall timeout in seconds
# @param {int} poll_interval_seconds Interval between status checks
# @param {int} wait_timeout_seconds Timeout for each kubectl wait call
# @return {int} 0 on success, 1 on timeout
wait_for_pods() {
    local timeout_seconds=$1
    local poll_interval_seconds=$2
    local wait_timeout_seconds=$3

    echo "Waiting for all pods to be ready" \
        "(timeout=${timeout_seconds}s, poll=${poll_interval_seconds}s," \
        "wait=${wait_timeout_seconds}s)..."

    # Reset bash built-in SECONDS counter
    SECONDS=0

    while true; do
        sleep "${poll_interval_seconds}"
        kubectl get pods

        if kubectl wait job \
                --all \
                --for=condition=Complete \
                --timeout="${wait_timeout_seconds}s" 2>/dev/null \
            && kubectl wait pods \
                --all \
                --selector='!job-name' \
                --for=condition=Ready \
                --timeout="${wait_timeout_seconds}s" 2>/dev/null
        then
            echo "All jobs completed and services are ready."
            return 0
        fi

        if [[ ${SECONDS} -ge ${timeout_seconds} ]]; then
            echo "ERROR: Timed out waiting for pods to be ready"
            return 1
        fi

        echo "---"
    done
}

# Waits for sample download to complete and all pods to be ready
wait_for_cluster_ready() {
    if wait "$SAMPLE_DOWNLOAD_PID"; then
        echo "Sample download and extraction complete"
    else
        echo "ERROR: Sample download failed"
        return 1
    fi

    wait_for_pods 300 5 5
}
